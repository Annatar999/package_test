import setuptools

setuptools.setup(
    name='itea',
    version='0.1',
    auther='NoName',
    auther_email='noname@gmail.com',
    packages=['itea'],
    python_requires='>=3.5',
)